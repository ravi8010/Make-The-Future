package com.capgemini.tests;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HomePage;
import com.capgemini.pages.LoginPage;

public class LoginPageTest extends TestBase{
	static LoginPage loginPage;
	static HomePage homePage;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@Test
	public void loginPageTitleTest(){
		String title = loginPage.validateLoginPageTitle();
		assertEquals(title, "CRM");
	}
	
	@Test
	public void loginTest() throws InterruptedException{
		homePage = loginPage.login("vikasjain98174@gmail.com", "vikash@0980");
		Thread.sleep(10000);
		assertTrue(homePage.checkImage());
	}
	
	
	
	@AfterClass
	public static  void tearDown(){
		driver.quit();
	}
	
	
	
	

}